package com.example.demo.entites;

public class ResponseResult {

}
